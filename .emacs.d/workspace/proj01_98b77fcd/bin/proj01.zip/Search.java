import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Search {
  HashMap<String, HashMap<String, Double>> adjList;
  HashMap<String, String> predMap;
  HashMap<String, double[]> locationData = new HashMap<>();
  LinkedList<String> path;

  public Search() {
    this.initialize();
    predMap = new HashMap<>();
  }

  public boolean contains(String city) {
    return locationData.keySet().contains(city);
  }

  public void printPath(BufferedWriter output, String header) throws IOException {
    double dist = 0;
    output.newLine();
    output.write(header);
    output.newLine();
    output.write(path.get(0));
    output.newLine();
    for (int i = 1; i < path.size(); i++) {
      dist += distance(path.get(i-1), path.get(i));
      output.write(path.get(i));
      output.newLine();
    }
    output.write("That took " + (path.size() - 1) + " hops to find.");
    output.newLine();
    output.write("Total distance = " + ((int) Math.round(dist)) + " miles.");
    output.newLine();
    output.newLine();
    output.flush();
  }

  public boolean BFS(String start, String end) {
    if (start.equals(end)) {
      path = new LinkedList<>();
      path.add(start);
      return true;
    }
    LinkedList<String> queue = new LinkedList<>();
    HashSet<String> visited = new HashSet<>();
    predMap.put(start, null);
    queue.offer(start);
    visited.add(start);
    while (!queue.isEmpty()) {
      String curr = queue.poll();
      ArrayList<String> neighbors = new ArrayList<>(adjList.get(curr).keySet());
      Collections.sort(neighbors);
      for (String other : neighbors) {
        if (other.equals(end)) {
          predMap.put(other, curr);
          buildPath(start, end);
          return true;
        }
        if (visited.add(other)) {
          predMap.put(other, curr);
          queue.offer(other);
        }
      }
    }
    return false;
  }

  public boolean DFS(String start, String end) {
    if (start.equals(end)) {
      path = new LinkedList<>();
      path.add(start);
      return true;
    }
    LinkedList<String> stack = new LinkedList<>();
    HashSet<String> visited = new HashSet<>();
    predMap.put(start, null);
    stack.push(start);
    visited.add(start);
    while (!stack.isEmpty()) {
      String curr = stack.pop();
      ArrayList<String> neighbors = new ArrayList<>(adjList.get(curr).keySet());
      Collections.sort(neighbors, Collections.reverseOrder());
      for (String other : neighbors) {
        if (other.equals(end)) {
          predMap.put(other, curr);
          buildPath(start, end);
          return true;
        }
        if (visited.add(other)) {
          predMap.put(other, curr);
          stack.push(other);
        }
      }
    }
    return false;
  }

  public boolean astar(String start, String end) {
    HashMap<String, Double> costSoFar = new HashMap<>();
    costSoFar.put(start, 0.0);
    PriorityQueue<String> queue = new PriorityQueue<>(10, new Comparator<String>() {
        public int compare(String a, String b) {
          return (int) (distance(a, end) + costSoFar.get(a) - distance(b, end) - costSoFar.get(b));
        }
      });
    queue.offer(start);
    while (!queue.isEmpty()) {
      String curr = queue.poll();
      if (curr.equals(end)) {
        buildPath(start, end);
        return true;
      }
      ArrayList<String> neighbors = new ArrayList<>(adjList.get(curr).keySet());
      for (String other : neighbors) {
        double guess = costSoFar.get(curr) + adjList.get(curr).get(other);
        if (!costSoFar.containsKey(other) || guess < costSoFar.get(other)) {
          predMap.put(other, curr);
          costSoFar.put(other, guess);
          if (!queue.contains(other)) {
            queue.offer(other);
          }
        }
      }
    }

    return false;
  }

  private void buildPath(String start, String end) {
    path = new LinkedList<>();
    path.addFirst(end);
    String curr = end;
    while (predMap.get(curr) != null) {
      curr = predMap.get(curr);
      path.addFirst(curr);
    }
  }

  private double distance(String start, String end) {
    double lat1 = locationData.get(start)[0];
    double lon1 = locationData.get(start)[1];
    double lat2 = locationData.get(end)[0];
    double lon2 = locationData.get(end)[1];
    return Math.sqrt((lat1 - lat2) * (lat1 - lat2) + (lon1 - lon2) * (lon1 - lon2)) * 100.0;
  }

  /**
   * Parses graph information and initializes object
   */
  private void initialize() {
    Scanner cityScanner = new Scanner(System.in);
    Scanner edgeScanner = new Scanner(System.in);
    try {
      cityScanner = new Scanner(new File("city.dat"));
    } catch (FileNotFoundException e) {
      System.err.println("File not found: city.dat");
      System.exit(0);
    }
    try {
      edgeScanner = new Scanner(new File("edge.dat"));
    } catch (FileNotFoundException e) {
      System.err.println("File not found: edge.dat");
      System.exit(0);
    }

    this.adjList = new HashMap<>();

    // load information from city.dat
    locationData = new HashMap<>();
    while (cityScanner.hasNextLine()) {
      String[] line = cityScanner.nextLine().split("\\s+");
      double[] loc = new double[2];
      loc[0] = Double.parseDouble(line[2]);
      loc[1] = Double.parseDouble(line[3]);
      locationData.put(line[0], loc);
    }
    cityScanner.close();

    // load information from edge.dat
    while (edgeScanner.hasNextLine()) {
      String[] line = edgeScanner.nextLine().split("\\s+");
      if (!adjList.containsKey(line[0]))
        adjList.put(line[0], new HashMap<>());
      if (!adjList.containsKey(line[1]))
        adjList.put(line[1], new HashMap<>());
      double dist = distance(line[0], line[1]);
      adjList.get(line[0]).put(line[1], dist);
      adjList.get(line[1]).put(line[0], dist);
    }

    edgeScanner.close();
  }

  public static void main(String[] args) {
    if (args.length != 2) {
      System.err.println("Usage: java Search inputFile outputFile");
      System.exit(0);
    }

    // setup I/O
    Scanner input = new Scanner(System.in);
    BufferedWriter output = new BufferedWriter(new OutputStreamWriter(System.out));
    try {
      if (!args[0].equals("-")) {
        input = new Scanner(new File(args[0]));
      }
    } catch (FileNotFoundException e) {
      System.err.println("File not found: " + args[0]);
      System.exit(0);
    }
    try {
      if (!args[1].equals("-")) {
        output = new BufferedWriter(new FileWriter(args[1]));
      }
    } catch (IOException e) {
      System.err.println("File not found: " + args[1]);
      System.exit(0);
    }

    try {
      Search s = new Search();
      String start = input.nextLine().trim();
      String end = input.nextLine().trim();
      if (!s.contains(start)) {
        System.err.println("No such city: " + start);
        System.exit(0);
      }
      if (!s.contains(end)) {
        System.err.println("No such city: " + end);
        System.exit(0);
      }
      s.BFS(start, end);
      s.printPath(output, "Breadth-First Search Results:");
      s.DFS(start, end);
      s.printPath(output, "Depth-First Search Results:");
      s.astar(start, end);
      s.printPath(output, "A* Search Results:");
    } catch (IOException e) {
      System.err.println("oops");
    }

  }
}
